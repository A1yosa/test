package com.tuzhi.dao;

import com.tuzhi.pojo.Role;

import java.util.List;


public interface RoleMapper {
    public List<Role> getRoleList()throws Exception;
}
