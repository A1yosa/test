package com.tuzhi.service.role;

import com.tuzhi.pojo.Role;

import java.util.List;


public interface RoleService {
    public List<Role> getRoleList();
}
