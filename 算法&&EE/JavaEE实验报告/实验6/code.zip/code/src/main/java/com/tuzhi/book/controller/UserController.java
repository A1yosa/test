package com.tuzhi.book.controller;

import com.tuzhi.book.pojo.User;
import com.tuzhi.book.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@Api(tags = "用户接口")
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/login")
    @ApiOperation("登录接口")
    public String login(@RequestBody User user) {
        if (userService.login(user) != 0) {
            return "登录成功";
        }else {

            return "账号或密码错误，请重新登录";
        }
    }

    @GetMapping("/hello")
    public String hello(){
        return "Hello";
    }

}
