package com.tuzhi.book.controller;

import com.tuzhi.book.pojo.Book;
import com.tuzhi.book.service.BookService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@Api(tags = "图书接口")
@RestController
@RequestMapping("/book")
public class BookController {

    @Autowired
    BookService bookService;

    @GetMapping()
    @ApiOperation("查询图书")
    public List<Book> getBookList() {
        List<Book> list = bookService.list();
        return list;
    }

    @ApiOperation("修改图书")
    @PostMapping("/update")
    public String updateBook(@RequestBody Book book) {
        boolean b = bookService.updateById(book);
        return b?"修改成功":"修改失败";
    }

    @ApiOperation("增加图书")
    @PostMapping("/add")
    public String addBook(@RequestBody Book book) {
        boolean save = bookService.save(book);
        return save?"添加成功":"添加失败";
    }

    @ApiOperation("删除图书")
    @DeleteMapping()
    public String deleteBook(@RequestBody Book book) {
        boolean b = bookService.removeById(book);
        return b?"删除成功":"删除失败";
    }


}
