package com.tuzhi.book.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.tuzhi.book.mapper.UserMapper;
import com.tuzhi.book.pojo.User;
import com.tuzhi.book.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImp extends ServiceImpl<UserMapper, User> implements UserService {

    @Override
    public int login(User user) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("username", user.getUsername());
        wrapper.eq("password", user.getPassword());
        int count = (int) this.count(wrapper);
        return count;
    }
}
