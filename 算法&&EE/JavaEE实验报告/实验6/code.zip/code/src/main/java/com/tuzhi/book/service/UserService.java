package com.tuzhi.book.service;

import com.tuzhi.book.pojo.User;
import com.baomidou.mybatisplus.extension.service.IService;


public interface UserService extends IService<User> {
    //登录接口
    int login(User user);
}
