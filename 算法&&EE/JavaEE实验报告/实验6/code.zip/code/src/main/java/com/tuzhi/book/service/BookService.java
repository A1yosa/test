package com.tuzhi.book.service;

import com.tuzhi.book.pojo.Book;
import com.baomidou.mybatisplus.extension.service.IService;


public interface BookService extends IService<Book> {

}
