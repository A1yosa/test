package com.tuzhi.book.service.impl;

import com.tuzhi.book.mapper.BookMapper;
import com.tuzhi.book.pojo.Book;
import com.tuzhi.book.service.BookService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;


@Service
public class BookServiceImp extends ServiceImpl<BookMapper, Book> implements BookService {

}
