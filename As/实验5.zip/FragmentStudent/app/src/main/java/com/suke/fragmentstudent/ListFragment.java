package com.suke.fragmentstudent;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ListFragment extends Fragment {
    private List<Student> list_stu = new ArrayList<>();
    private StudentAdapter adapter;
    private EditText editId;
    private EditText editName;
    private EditText editTel;
    private Button btnCommit;
    private ListView lvStu;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        initView(view);
        initData();
        return view;
    }

    private void initData() {
        for (int i = 1; i < 6; i++) {
            list_stu.add(new Student("1920013522" + i, "书启秋枫" + i, "1531214566" + i));
        }
        adapter = new StudentAdapter();
        lvStu.setAdapter(adapter);

    }

    private void initView(View view) {
        editId = (EditText) view.findViewById(R.id.edit_id);
        editName = (EditText) view.findViewById(R.id.edit_name);
        editTel = (EditText) view.findViewById(R.id.edit_tel);
        btnCommit = (Button) view.findViewById(R.id.btn_commit);
        lvStu = (ListView) view.findViewById(R.id.lv_stu);

        btnCommit.setOnClickListener(v -> {
            String id = editId.getText().toString();
            String name = editName.getText().toString();
            String tel = editTel.getText().toString();
            editId.setText("");
            editName.setText("");
            editTel.setText("");
            list_stu.add(new Student(id, name, tel));
            adapter.notifyDataSetChanged();
        });

    }

    private class StudentAdapter extends BaseAdapter {
        private TextView tvId;
        private TextView tvName;
        private ImageView imageView;
        private TextView tvTel;
        private ImageButton btnDelete;


        @Override
        public int getCount() {
            return list_stu.size();
        }

        @Override
        public Object getItem(int position) {
            return list_stu.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_layout, parent, false);
            tvId = (TextView) convertView.findViewById(R.id.tv_id);
            tvName = (TextView) convertView.findViewById(R.id.tv_name);
            imageView = (ImageView) convertView.findViewById(R.id.imageView);
            tvTel = (TextView) convertView.findViewById(R.id.tv_tel);
            btnDelete = (ImageButton) convertView.findViewById(R.id.btn_delete);

            tvId.setText(list_stu.get(position).getSno());
            tvName.setText(list_stu.get(position).getSname());
            tvTel.setText(list_stu.get(position).getStele());

            tvTel.setOnClickListener(v -> {
                String tel = list_stu.get(position).getStele();
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + tel));
                startActivity(intent);
            });

            btnDelete.setOnClickListener(v -> {
                list_stu.remove(position);
                adapter.notifyDataSetChanged();
            });

            return convertView;
        }
    }
}