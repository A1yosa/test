package com.suke.recyclerstudentsqlite;

public class Student {
    private String Sno;
    private String Sname;
    private String Stele;
    private int imageId;

    public Student() {
    }

    public Student(String sno, String sname, String stele) {
        Sno = sno;
        Sname = sname;
        Stele = stele;
    }

    public Student(String sno, String sname, String stele, int imageId) {
        Sno = sno;
        Sname = sname;
        Stele = stele;
        this.imageId = imageId;
    }

    public String getSno() {
        return Sno;
    }

    public void setSno(String sno) {
        Sno = sno;
    }

    public String getSname() {
        return Sname;
    }

    public void setSname(String sname) {
        Sname = sname;
    }

    public String getStele() {
        return Stele;
    }

    public void setStele(String stele) {
        Stele = stele;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }
}
