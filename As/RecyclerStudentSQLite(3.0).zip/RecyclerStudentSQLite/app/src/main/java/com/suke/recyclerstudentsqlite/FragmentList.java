package com.suke.recyclerstudentsqlite;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FragmentList extends Fragment {

    //控制台打印提示
    private final String TagCreate = "create";
    private final String TagDelete = "delete";
    //创建学生信息列表
    private List<Student> dataStu = new ArrayList<>();
    //学号、姓名、手机号
    private EditText editId;
    private EditText editName;
    private EditText editTel;
    //头像
    private ImageView imageView;
    //添加学生信息按钮
    private Button btnCommit;
    //添加通讯录联系人信息
    private Button btnGetPhoneInfo;
    //RecyclerView的工具类
    private StudentAdapter studentAdapter;
    //学生信息视图列表
    private RecyclerView rcvStu;
    //数据库读写
    SQLiteDatabase readableDatabase;
    SQLiteDatabase writableDatabase;
    ContentValues values;

    /*String[] ids = new String[]{"19200135221", "19200135222", "19200135223", "19200135224", "19200135225", "19200135226"};
    String[] names = new String[]{"书启秋枫", "Gaze", "无羡", "阿斌", "家和万事兴", "Suk"};
    String[] tels = new String[]{"15312133001", "153121330012", "153121330013", "153121330014", "153121330015", "153121330016"};*/
    //数组存图片
    int[] images = new int[]{R.drawable.ls, R.drawable.cc, R.drawable.mr, R.drawable.zb, R.drawable.zjh, R.drawable.lishuo};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        check();
    }

    //检查获取通讯录权限
    private void check() {
        //判断是否有权限
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_CONTACTS}, 201);
        } else {
            return;
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //1.获取fragment_list视图
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        //2.初始化视图
        initView(view);
        //3.初始化数据
        initData();
        //4.返回视图
        return view;
    }

    //刷新学生列表
    public void refreshList() {
        //清空学生列表
        dataStu.clear();
        //cursor游标读取数据库内容
        Cursor cursor = readableDatabase.query("students", null, null, null, null, null, null);
        //游标获取学生学号、姓名、手机号、图片号
        while (cursor.moveToNext()) {
            @SuppressLint("Range") String stu_id = cursor.getString(cursor.getColumnIndex("stu_id"));
            @SuppressLint("Range") String stu_name = cursor.getString(cursor.getColumnIndex("stu_name"));
            @SuppressLint("Range") String stu_tel = cursor.getString(cursor.getColumnIndex("stu_tel"));
            @SuppressLint("Range") Integer stu_image = cursor.getInt(cursor.getColumnIndex("stu_image"));
            dataStu.add(new Student(stu_id, stu_name, stu_tel, stu_image));
        }
    }

    //2.初始化视图
    private void initView(View view) {
        editId = view.findViewById(R.id.edit_id);
        editName = view.findViewById(R.id.edit_name);
        editTel = view.findViewById(R.id.edit_tel);
        btnCommit = view.findViewById(R.id.btn_commit);
        imageView = view.findViewById(R.id.image_stu);
        rcvStu = view.findViewById(R.id.rcv_stu);
        btnGetPhoneInfo = view.findViewById(R.id.btn_getPhone);

        //设置 recyclerview 显示布局
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        rcvStu.setLayoutManager(linearLayoutManager);

    }

    //3.初始化数据
    private void initData() {
        //创建数据库 Student.db
        SQLiteOpenHelper helper = MySqlite.getInstance(getContext());
        //只有执行下面才能创建出数据库和表 students
        writableDatabase = helper.getWritableDatabase();
        readableDatabase = helper.getReadableDatabase();
        //刷新学生列表获取学生数据库信息
        refreshList();

        //选择随机头像
        final int[] random = {0};
        imageView.setOnClickListener(v -> {
            random[0] = new Random().nextInt(6);
            imageView.setImageResource(images[random[0]]);
        });

        //获取通讯录联系人信息
        btnGetPhoneInfo.setOnClickListener(v -> {
            PhoneInfo phoneInfo = new PhoneInfo(getContext());
            dataStu = phoneInfo.getPhone();
            String id = editId.getText().toString();
            for (Student s : dataStu) {
                if (id.equals(s.getSno())) {
                    editName.setText(s.getSname());
                    editTel.setText(s.getStele());
                } else {
                    Toast.makeText(getContext(), "学号错误！无法找到该联系人", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //添加学生信息(lambda表达式)
        btnCommit.setOnClickListener(v -> {
            String id = editId.getText().toString();
            String name = editName.getText().toString();
            String tel = editTel.getText().toString();
            //向数据表 添加学生信息
            values = new ContentValues();
            values.put("stu_id", id);
            values.put("stu_name", name);
            values.put("stu_tel", tel);
            values.put("stu_image", random[0]);
            if (writableDatabase.insert("students", null, values) > 0) {
                refreshList();
                Toast.makeText(getContext(), "创建成功！", Toast.LENGTH_SHORT).show();
                Log.e(TagCreate, "学生创建成功");
                //将添加学生信息处置空
                editId.setText("");
                editName.setText("");
                editTel.setText("");
                studentAdapter.notifyDataSetChanged();
            }

        });
        studentAdapter = new StudentAdapter();
        rcvStu.setAdapter(studentAdapter);
    }

    private class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.MyViewHolder> {

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = View.inflate(getContext(), R.layout.list_item_layout, null);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            holder.tvId.setText(dataStu.get(position).getSno());
            holder.tvName.setText(dataStu.get(position).getSname());
            holder.tvTel.setText(dataStu.get(position).getStele());
            holder.imageView.setImageResource(images[dataStu.get(position).getImageId()]);

            //拨打电话(隐式调用)
            holder.btnCall.setOnClickListener(v -> {
                String tel = dataStu.get(position).getStele();
                //传入两个参数(一个是拨号盘，一个是电话号)
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + tel));
                //实例化之后startActivity执行
                startActivity(intent);
            });

            //切换随机头像
            holder.imageView.setOnClickListener(v -> {
                Random random = new Random();
                holder.imageView.setImageResource(images[random.nextInt(6)]);
            });

            //删除学生信息
            holder.btnDelete.setOnClickListener(v -> {
                //数据库删除学生信息
                writableDatabase.delete("students", "stu_id=?", new String[]{(dataStu.get(position).getSno())});
                Toast.makeText(getContext(), "删除成功！", Toast.LENGTH_SHORT).show();
                dataStu.remove(position);
                studentAdapter.notifyDataSetChanged();
                Log.e(TagDelete, "学生已删除");
            });
        }

        //RecyclerView视图列表展示数量
        @Override
        public int getItemCount() {
            //判断是否为空
            return dataStu == null ? 0 : dataStu.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            //学号、姓名、手机号
            private TextView tvId;
            private TextView tvName;
            private TextView tvTel;
            //学生头像
            private ImageView imageView;
            //拨打电话
            private Button btnCall;
            //删除学生
            private ImageButton btnDelete;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                tvId = itemView.findViewById(R.id.tv_id);
                tvName = itemView.findViewById(R.id.tv_name);
                tvTel = itemView.findViewById(R.id.tv_tel);
                imageView = itemView.findViewById(R.id.imageView);
                btnCall = itemView.findViewById(R.id.btn_call);
                btnDelete = itemView.findViewById(R.id.btn_delete);
            }
        }
    }
}