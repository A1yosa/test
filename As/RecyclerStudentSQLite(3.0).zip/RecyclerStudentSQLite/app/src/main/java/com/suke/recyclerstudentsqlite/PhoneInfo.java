package com.suke.recyclerstudentsqlite;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import java.util.ArrayList;
import java.util.List;

public class PhoneInfo {
    // 序号
    public final static String ID = ContactsContract.CommonDataKinds.Phone.CONTACT_ID;
    // 号码
    public final static String NUM = ContactsContract.CommonDataKinds.Phone.NUMBER;
    // 联系人姓名
    public final static String NAME = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME;

    //上下文对象
    private Context context;
    //联系人提供者的uri
    private Uri phoneUri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;

    public PhoneInfo(Context context) {
        this.context = context;
    }

    //获取所有联系人
    public List<Student> getPhone() {
        List<Student> dataStu = new ArrayList<>();
        ContentResolver cr = context.getContentResolver();
        Cursor cursor = cr.query(phoneUri, new String[]{ID, NUM, NAME}, null, null, null);
        while (cursor.moveToNext()) {
            @SuppressLint("Range") Student student = new Student(cursor.getString(cursor.getColumnIndex(ID)), cursor.getString(cursor.getColumnIndex(NAME)), cursor.getString(cursor.getColumnIndex(NUM)));
            dataStu.add(student);
        }
        return dataStu;
    }
}