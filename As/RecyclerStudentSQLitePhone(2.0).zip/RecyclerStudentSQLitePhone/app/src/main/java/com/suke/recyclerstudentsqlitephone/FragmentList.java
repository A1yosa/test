package com.suke.recyclerstudentsqlitephone;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class FragmentList extends Fragment {

    //控制台打印提示
    private final String TagCreate = "create";
    private final String TagDelete = "delete";
    //创建学生信息列表
    private List<Student> dataStu = new ArrayList<>();
    private Student student;
    //学号、姓名、手机号
    private EditText editId;
    private EditText editName;
    private EditText editTel;
    //头像
    private ImageView imageView;
    //添加学生信息按钮
    private Button btnCommit;
    //RecyclerView的工具类
    private StudentAdapter studentAdapter;
    //学生信息视图列表
    private RecyclerView rcvStu;
    //数据库读写
    SQLiteDatabase readableDatabase;
    SQLiteDatabase writableDatabase;
    ContentValues values;
    //拍照、相册
    public static final int TAKE_PHOTO = 1;
    public static final int CHOOSE_PHOTO = 2;
    //头像地址
    private Uri imageUri;
    //头像转字节存储
    private byte[] in;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //1.获取fragment_list视图
        View view = inflater.inflate(R.layout.fragment_list, container, false);
        //2.初始化视图
        initView(view);
        //3.初始化数据
        initData();
        //4.返回视图
        return view;
    }

    //刷新学生列表
    @SuppressLint("Range")
    public void refreshList() {
        //清空学生列表
        dataStu.clear();
        //cursor游标读取数据库内容
        Cursor cursor = readableDatabase.query("students", null, null, null, null, null, null);
        //游标获取学生学号、姓名、手机号、图片号
        while (cursor.moveToNext()) {
            @SuppressLint("Range") String stu_id = cursor.getString(cursor.getColumnIndex("stu_id"));
            @SuppressLint("Range") String stu_name = cursor.getString(cursor.getColumnIndex("stu_name"));
            @SuppressLint("Range") String stu_tel = cursor.getString(cursor.getColumnIndex("stu_tel"));
            @SuppressLint("Range") byte[] stu_image = cursor.getBlob(cursor.getColumnIndex("stu_image"));
            dataStu.add(new Student(stu_id, stu_name, stu_tel, stu_image));
        }
    }

    //2.初始化视图
    private void initView(View view) {
        editId = view.findViewById(R.id.edit_id);
        editName = view.findViewById(R.id.edit_name);
        editTel = view.findViewById(R.id.edit_tel);
        btnCommit = view.findViewById(R.id.btn_commit);
        imageView = view.findViewById(R.id.image_stu);
        rcvStu = view.findViewById(R.id.rcv_stu);

        //设置 recyclerview 显示布局
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        rcvStu.setLayoutManager(linearLayoutManager);
    }

    //3.初始化数据
    private void initData() {
        //创建数据库 Student.db
        SQLiteOpenHelper helper = MySqlite.getInstance(getContext());
        //只有执行下面才能创建出数据库和表 students
        writableDatabase = helper.getWritableDatabase();
        readableDatabase = helper.getReadableDatabase();
        //刷新学生列表获取学生数据库信息
        refreshList();

        //拍照或相册选择头像
        imageView.setOnClickListener(v -> {
            final String[] items = new String[]{"拍照", "相册"};
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle("请选择头像获取方式:");
            builder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int which) {
                    switch (items[which]) {
                        case "拍照":
                            takePhoto();
                            break;
                        case "相册":
                            choosePhoto();
                            break;
                    }
                }
            });
            builder.create().show();
        });

        //添加学生信息(lambda表达式)
        btnCommit.setOnClickListener(v -> {
            String id = editId.getText().toString();
            String name = editName.getText().toString();
            String tel = editTel.getText().toString();

            //向数据表 添加学生信息
            values = new ContentValues();
            values.put("stu_id", id);
            values.put("stu_name", name);
            values.put("stu_tel", tel);
            values.put("stu_image", in);
            if (writableDatabase.insert("students", null, values) > 0) {
                refreshList();
                Toast.makeText(getContext(), "创建成功！", Toast.LENGTH_SHORT).show();
                Log.e(TagCreate, "学生创建成功");
                //将添加学生信息处置空
                editId.setText("");
                editName.setText("");
                editTel.setText("");
                studentAdapter.notifyDataSetChanged();
            }
        });
        studentAdapter = new StudentAdapter();
        rcvStu.setAdapter(studentAdapter);
    }

    //拍照获取头像
    public void takePhoto() {
        File outputImage = new File(getContext().getExternalCacheDir(), "output_image.jpg");
        try {
            if (outputImage.exists()) {
                outputImage.delete();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            imageUri = FileProvider.getUriForFile(getContext(), "com.suke.pickphoto.fileprovider", outputImage);
        } else {
            imageUri = Uri.fromFile(outputImage);
        }

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, TAKE_PHOTO);
    }

    //相册获取头像
    public void choosePhoto() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, CHOOSE_PHOTO);
    }

    private byte[] getImg(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        return baos.toByteArray();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == getActivity().RESULT_OK) {
            switch (requestCode) {
                case TAKE_PHOTO:
                    try {
                        Bitmap bitmap = BitmapFactory.decodeStream(getContext().getContentResolver().openInputStream(imageUri));
                        imageView.setImageBitmap(bitmap);
                        in = getImg(bitmap);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    break;
                case CHOOSE_PHOTO:
                    Uri uri = data.getData();
                    Cursor c = getContext().getContentResolver().query(uri, new String[]{MediaStore.Images.Media.DATA}, null, null, null);
                    if (c != null) {
                        c.moveToFirst();
                        @SuppressLint("Range")
                        String path = c.getString(c.getColumnIndex(MediaStore.Images.Media.DATA));
                        Bitmap bitmap = BitmapFactory.decodeFile(path);
                        imageView.setImageBitmap(bitmap);
                        in = getImg(bitmap);
                    }
                    break;
            }
        }
    }

    private class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.MyViewHolder> {

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = View.inflate(getContext(), R.layout.list_item_layout, null);
            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
            holder.tvId.setText(dataStu.get(position).getSno());
            holder.tvName.setText(dataStu.get(position).getSname());
            holder.tvTel.setText(dataStu.get(position).getStele());

            //字节码头像转换获取
            byte[] in = dataStu.get(position).getSimage();
            Bitmap bitmap = BitmapFactory.decodeByteArray(in, 0, in.length);
            holder.imageView.setImageBitmap(bitmap);

            //拨打电话(隐式调用)
            holder.btnLook.setOnClickListener(v -> {
                String tel = dataStu.get(position).getStele();
                //传入两个参数(一个是拨号盘，一个是电话号)
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + tel));
                //实例化之后startActivity执行
                startActivity(intent);
            });

            //删除学生信息
            holder.btnDelete.setOnClickListener(v -> {
                AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                alertDialog.setIcon(holder.imageView.getDrawable());
                alertDialog.setTitle("联系人: " + holder.tvName.getText());
                alertDialog.setMessage("学号:" + holder.tvId.getText() + "\n手机号: " + holder.tvTel.getText());
                alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "否", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getContext(), "你选择了否！", Toast.LENGTH_SHORT).show();
                    }
                });
                alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "是", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //数据库删除学生信息
                        writableDatabase.delete("students", "stu_id=?", new String[]{(dataStu.get(position).getSno())});
                        Toast.makeText(getContext(), "删除成功！", Toast.LENGTH_SHORT).show();
                        dataStu.remove(position);
                        studentAdapter.notifyDataSetChanged();
                        Log.e(TagDelete, "学生已删除");
                    }
                });
                alertDialog.show();
            });
        }

        //RecyclerView视图列表展示数量
        @Override
        public int getItemCount() {
            //判断是否为空
            return dataStu == null ? 0 : dataStu.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            //学号、姓名、手机号
            private TextView tvId;
            private TextView tvName;
            private TextView tvTel;
            //学生头像
            private ImageView imageView;
            //查看学生信息
            private Button btnLook;
            //删除学生
            private ImageButton btnDelete;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                tvId = itemView.findViewById(R.id.tv_id);
                tvName = itemView.findViewById(R.id.tv_name);
                tvTel = itemView.findViewById(R.id.tv_tel);
                imageView = itemView.findViewById(R.id.imageView);
                btnLook = itemView.findViewById(R.id.btn_look);
                btnDelete = itemView.findViewById(R.id.btn_delete);
            }
        }
    }
}