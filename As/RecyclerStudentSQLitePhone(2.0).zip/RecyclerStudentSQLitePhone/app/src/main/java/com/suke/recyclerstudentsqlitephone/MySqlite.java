
package com.suke.recyclerstudentsqlitephone;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

/*
 * MySqlite 工具类  单例模式(1.构造函数私有化  2.对外提供函数)
 * */

public class MySqlite extends SQLiteOpenHelper {

    //2.对外提供函数
    private static SQLiteOpenHelper mInstance;

    public static synchronized SQLiteOpenHelper getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new MySqlite(context, "Student.db", null, 1);
        }
        return mInstance;
    }

    //1.构造函数私有化
    public MySqlite(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    /*
     * 数据初始化时使用的
     * 创建表   表数据初始化  数据库第一次创建的时候调用
     * 第二次发现表已存在 就不会重复创建了: 意味着此函数只会执行一次
     * */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "CREATE TABLE IF NOT EXISTS students (" +
                "stu_id TEXT PRIMARY KEY, " +
                "stu_name TEXT, " +
                "stu_tel TEXT," +
                "stu_image text" +
                ")";
        sqLiteDatabase.execSQL(sql);
    }

    //数据库升级用的
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}