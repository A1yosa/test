package com.suke.recyclerstudentsqlitephone;

import android.graphics.Bitmap;

public class Student {
    private String Sno;
    private String Sname;
    private String Stele;
    private byte[] Simage;

    public Student() {
    }

    public Student(String sno, String sname, String stele, byte[] simage) {
        Sno = sno;
        Sname = sname;
        Stele = stele;
        Simage = simage;
    }


    public String getSno() {
        return Sno;
    }

    public void setSno(String sno) {
        Sno = sno;
    }

    public String getSname() {
        return Sname;
    }

    public void setSname(String sname) {
        Sname = sname;
    }

    public String getStele() {
        return Stele;
    }

    public void setStele(String stele) {
        Stele = stele;
    }

    public byte[] getSimage() {
        return Simage;
    }

    public void setSimage(byte[] simage) {
        Simage = simage;
    }
}
