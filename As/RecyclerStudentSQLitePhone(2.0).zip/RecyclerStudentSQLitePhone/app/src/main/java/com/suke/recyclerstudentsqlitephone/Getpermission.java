package com.suke.recyclerstudentsqlitephone;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Getpermission {

    public static final int REQUEST_CODE = 5;
    private static final String[] permission = new String[]{
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
    };

    public static void requestPermission(Activity activity){
        //判断是否有权限
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED){
            //索取权限
            ActivityCompat.requestPermissions(activity,new String[]{Manifest.permission.READ_CONTACTS},1);
        }else {
            //说明已经有权限了，无需再获取
        }
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_CONTACTS)!= PackageManager.PERMISSION_GRANTED){
            //索取权限
            ActivityCompat.requestPermissions(activity,new String[]{Manifest.permission.WRITE_CONTACTS},1);
        }else {
            //说明已经有权限了，无需再获取
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode==1){
            if (grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                //用户点了同意获取权限
            }else{
                //用户点了拒绝获取权限
            }
        }
    }

    public static boolean isPermissionGranted(Activity activity) {
        if (Build.VERSION.SDK_INT >= 23) {
            for (int i = 0; i < permission.length; i++) {
                int checkPermission = ContextCompat.checkSelfPermission(activity, permission[i]);
                if (checkPermission != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean checkPermission(Activity activity) {
        if (isPermissionGranted(activity)) {
            return true;
        } else {
            ActivityCompat.requestPermissions(activity, permission, REQUEST_CODE);
            return false;
        }
    }
}