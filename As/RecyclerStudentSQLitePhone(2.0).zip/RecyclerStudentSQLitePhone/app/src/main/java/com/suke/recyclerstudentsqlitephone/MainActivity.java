package com.suke.recyclerstudentsqlitephone;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentManager fm = getSupportFragmentManager();
        Fragment fragment = fm.findFragmentById(R.id.fragment_list);
        if (fragment == null) {
            fragment = new FragmentList();
            fm.beginTransaction()
                    .add(R.id.fragment_list, fragment)
                    .commit();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Getpermission.checkPermission(this);
    }
}